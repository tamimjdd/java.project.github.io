Netbeans 8.0.2 javascript editor jar files
==========================================

Netbeans 8.0.2 after latest update start scan projects forever with CPU load at 25%.

In this repo I place [files](https://github.com/uran1980/nb-8.0.2-javascript-editor-files/tree/master/ide/modules) from prev release 8.0.2 before last update (2015-03-08). When you replace new files in netbens modules ```NetBeans 8.0.2\ide\modules``` with files from this repository than project scaning start to work correct.

For mor info please see this [stackoverflow](http://stackoverflow.com/questions/28811246/netbeans-background-scanning-projects-takes-too-long) thread and [this bugreport](https://netbeans.org/bugzilla/show_bug.cgi?id=250985).
